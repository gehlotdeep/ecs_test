1. update the Dockerfile
